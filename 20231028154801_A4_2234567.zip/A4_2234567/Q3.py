"""
student: larissa
question 3 - Which numbers will be a part of the output list of the following Python code?
def sf(a):
    return a%3!=0 and a%5!=0
m=filter(sf, range(1,31))
print(list(m))
"""
##  [1, 2, 4, 7, 8, 11, 13, 14, 16, 17, 19, 22, 23, 26, 28, 29] ##

# the output is numbers in the range of 30 that are NOT divided by 3 AND 5