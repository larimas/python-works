"""
student: larissa
question Question 4: Implement a python program to check if a number is an Armstrong number by using lambda, map, and filter.
An Armstrong number of three digits is an integer such that the sum of the cubes of its digits is equal to the number itself. 
For example, 371 is an Armstrong number since 3**3 + 7**3 + 1**3 = 371.
"""
"""
by reference and understanding: programiz.com
"A positive integer is called an Armstrong number of order n if

abcd... = an + bn + cn + dn + ... // n elevado? search for the word in english
In case of an Armstrong number of 3 digits, the sum of cubes of each digit is equal to the number itself. For example:

153 = 1*1*1 + 5*5*5 + 3*3*3  // 153 is an Armstrong number."
"""
## ask the input from the user
num = int(input("Enter a number with 3 digits: "))

# state and put the calc
sum = 0
armstrong_num = num
while armstrong_num > 0:
   digit = armstrong_num % 10
   sum += digit ** 3
   armstrong_num //= 10

if num == sum:
   print(num,"it's an Armstrong number")
else:
   print(num,"isn't an Armstrong number")

