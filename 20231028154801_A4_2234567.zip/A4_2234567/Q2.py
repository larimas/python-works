"""
student: larissa
question 2 - The single line equivalent of the following Python code?
l=[1,2,3,4,5]
def f1(x):
    return x<0
m1=filter(f1, l)
print(list(m1))
"""
list = [1,2,3,4,5]
q2 = [x for x in list if x < 0]
print(q2)

## for numbers below 0 in the given list which doesn't apply so the output is []/null