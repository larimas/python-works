"""
student: larissa
question 1 - Question 1: What are the outputs for the following codes?"""

"""
## 
LETTER A
## it's printing 10 numbers so the output will be the numbers from 0 to 10 excluding the 10
## 
LETTER B
## the output is "TRUE TRUE 1 2", it goes smoothly 
# until the del so it appears an exception so maybe deleting the del
## and putting to print only even or odd numbers as a new list would be a solution?
## 
LETTER C
## false, true - it's the output
## the lambda is for odd or even numbers so 20 even and 21 is odd
## 
LETTER D
## the input is 24 because is doing the multiplication between the
## 4 numbers so: 1*2=result*3=the result*4. 
## 
LETTER E
## this returns 1, -2 and -3. the output is supposed to be the numbers
## below 2 in the list given [1,-2,-3,4,5]
## 
LETTER F
## the same reason as the letter E but with map that acts like a filter 
## so it'll pass each number to check if it's below -1 so this returns [False, True, True, False, False]
## 
LETTER G
## the output is 5 because just like the others with lambda uses the reduce
## to compare the numbers between each other and return the largest one
## 
LETTER H
## doesn't have an output: it says that the reduce is not defined
even putting functools before the reduce doesn't work because we didn't defined the list for example because
we only got 1 argument, not 2
"""