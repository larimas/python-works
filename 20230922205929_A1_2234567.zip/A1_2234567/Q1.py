"student: larissa"
"assingment 1 - question 1"

firstnum = int(input("Enter the first number: "))
secondnum = int(input("Enter the second number: "))
product = firstnum * secondnum
sum = firstnum + secondnum

if (product > 1000):
    print ("The sum of", firstnum, "and", secondnum, "is:", sum)
else:
    print ("The product of", firstnum, "and",secondnum, "is:", product)
