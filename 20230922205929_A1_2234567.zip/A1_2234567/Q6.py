"student: larissa"
"assingment 1 - question 6"

string1 = input("Enter the 1st string: ")
string2 = input("Enter the 2nd string: ")

lenght_string1 = len(string1)
middle_string1 = lenght_string1 // 2
result = string1[:middle_string1] + string2 + string1[middle_string1:]
print("Result:", result)