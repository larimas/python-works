"student: larissa"
"assingment 1 - question 4"

def remove_chars(string, n):
    return string[n:]

string_input = input('Enter a string: ')
number = int(input('Enter an int value: '))

result = remove_chars(string_input, number)
print("The final string is: ", result)
