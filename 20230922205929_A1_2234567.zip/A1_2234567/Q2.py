"student: larissa"
"assingment 1 - question 2"

print("Enter 5 values :")
num1 = int(input("Number 1: "))
num2 = int(input("Number 2: "))
num3 = int(input("Number 3: "))
num4 = int(input("Number 4: "))
num5 = int(input("Number 5: "))
print("-----------------------")

sum = num1 + num2 + num3 + num4 + num5
result = sum/5
print("The resulf of ", num1, "," , num2, ",", num3, ",", num4, ",", num5, "is", result)