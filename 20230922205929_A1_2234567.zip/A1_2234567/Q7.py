"student: larissa"
"assingment 1 - question 7"

string = "Welcome to USA. usa awesome, isn't it?"

def find_usa_occurrences(string):
    string = string.lower()
    return string.count("usa")

occurrences = find_usa_occurrences(string)
print("Occurrences of 'USA':", occurrences)