"student: larissa"
"assingment 1 - question 3"

def middle_three_chars(s):
    middle_index = len(s) // 2
    return s[middle_index - 1:middle_index + 2]

input_string = input("Enter a string with odd length greater than 7: ")
if len(input_string) > 7 and len(input_string) % 2 == 1:
    result = middle_three_chars(input_string)
    print("Result:", result)
else:
    print("Please enter a valid string with odd length greater than 7.")