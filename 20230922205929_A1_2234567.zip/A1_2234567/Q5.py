"student: larissa"
"assingment 1 - question 5"

numbers = [1,2,3,4,5,6,7,8,9,10]
list_lenght = len(numbers)
if numbers[0] == numbers[list_lenght -1]:
    print ("True")
else:
    print ("False")

numbers = [1,2,3,4,5,6,7,8,9,1]
list_lenght = len(numbers)
if numbers[0] == numbers[list_lenght -1]:
    print ("True")
else:
    print ("False")