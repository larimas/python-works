"""
student: larissa
************************ QUESTION 2 **********************
1)Create a new project: ProjectCircle
2)Create a package: basisclasses
basisclasses (for the class Circle)
3)Create the class Circle with the following characteristics.
- circleId string (it starts with CIR_ and increases by 1)  CIR_1 , CIR_2 ….
-radius float (the radius of the circle)
-color string (the color of the circle) default color is red
Constructors :
-Constructor with all required attributes
Methods :
-This class provides methods that access to all attributes
-This class overrides the following methods delete and str to return the following output:
Circle Id : …Radius : … Color : … Perimeter : …. Area: …
4)Create main.py with the following
oBuild three circles, one of them with the color red
odisplay them

"""
class Circle:
    circleId_counter = 0

    def __init__(self, radius, color="red"):
        self.circleId = self.generate_circle_id()
        self.radius = radius
        self.color = color

    def generate_circle_id(self):
        Circle.circleId_counter += 1
        return f"CIR_{Circle.circleId_counter}"

    def calc_perimeter(self):
        return 2 * 3.14 * self.radius
    def calc_area(self):
        return 3.14 * (self.radius ** 2)

    def __str__(self):
        return f"Circle nº ID {self.circleId} with radius {self.radius} and color {self.color} will have perimeter {self.calc_perimeter()} and area {self.calc_area()}."