"""
student: larissa
************************ QUESTION 2 **********************
1)Create a new project: ProjectCircle
2)Create a package: basisclasses
basisclasses (for the class Circle)
3)Create the class Circle with the following characteristics.
- circleId string (it starts with CIR_ and increases by 1)  CIR_1 , CIR_2 ….
-radius float (the radius of the circle)
-color string (the color of the circle) default color is red
Constructors :
-Constructor with all required attributes
Methods :
-This class provides methods that access to all attributes
-This class overrides the following methods delete and str to return the following output:
Circle Id : …Radius : … Color : … Perimeter : …. Area: …
4)Create main.py with the following
oBuild three circles, one of them with the color red
odisplay them

"""

from circle import Circle

def displayAllCircles(circles):
    for circle in circles:
        print(circle)

circles = [
    Circle(1, "Pink"),
    Circle(2, "Orange"),
    Circle(3)
]
displayAllCircles(circles)
