"""
student: larissa
************************ QUESTION 1 **********************
1)Create a new project: ProjectBook
2)Create a package: basisclasses
basisclasses (for the class Book)
3)Create the class Book with the following characteristics.
-bookId int (it starts with 1 and increases by 1)
-bookTitle string (the name of the book)
-bookAuthor string (the name of the author)
-bookEditor string (the name of the editor)
-bookPrice float (the price of the book)
-
Constructors :
-Constructor with all required attributes
Methods :
-This class provides methods that access to all attributes and only modifies the attribute price
-This class overrides the method str to return the following output:
Book id : …Book name : … Author Name : … Price : …..
4)Create main.py with the following
oBuild five books
odisplayAllBooks

"""

from book import Book

def displayAllBooks(books):
    for book in books:
        print(book)

books = [
    Book("Little Women", "Author 1", "Editor 1", 25),
    Book("Harry Potter", "Author 2", "Editor 2", 30),
    Book("Dune", "Author 3", "Editor 3", 35),
    Book("Lord of the Rings", "Author 4", "Editor 4", 40),
    Book("Game of Thrones", "Author 5", "Editor 5", 45)
]

displayAllBooks(books)