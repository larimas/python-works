"""
student: larissa
************************ QUESTION 1 **********************
1)Create a new project: ProjectBook
2)Create a package: basisclasses
basisclasses (for the class Book)
3)Create the class Book with the following characteristics.
-bookId int (it starts with 1 and increases by 1)
-bookTitle string (the name of the book)
-bookAuthor string (the name of the author)
-bookEditor string (the name of the editor)
-bookPrice float (the price of the book)
-
Constructors :
-Constructor with all required attributes
Methods :
-This class provides methods that access to all attributes and only modifies the attribute price
-This class overrides the method str to return the following output:
Book id : …Book name : … Author Name : … Price : …..
4)Create main.py with the following
oBuild five books
odisplayAllBooks

"""

class Book:
    bookId_counter = 0

    def __init__(self, title, author, editor, price):
        self.bookId = self.generate_book_id()
        self.title = title
        self.author = author
        self.editor = editor
        self.price = price

    def generate_book_id(self):
        Book.bookId_counter += 1
        return Book.bookId_counter

    def set_price(self, new_price):
        self.price = new_price

    def __str__(self):
        return f"Book nº ID {self.bookId} with title as {self.title} by {self.author} and price ${self.price}."