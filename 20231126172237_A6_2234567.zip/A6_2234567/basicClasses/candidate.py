"""
student: larissa
question 4:
4.Create the class Candidate that inherits from Person with the following characterises:
• Attributes:
▪ certificationExam (type CertificationExam)
▪ examDate
▪ examMark
▪ grade
▪ nbDaysToWait
• Constructor:
▪ Create a parameterized constructor and initialize super class with all attributes of super class and also examDate and certificationExam.
• Methods:
▪ The class provides access methods and modifies the attributes for examDate, examMark and certificationExam
▪ Create serviceSuccess method that takes grade and initialize the grade attribute.
▪ Create serviceFaillure method that takes number of days and initialize the nbDaysToWait attribute.
▪ The class overrides the method toString() to check whether the candidate passed or failed the exam and display a message for success and failure with a message return the following output :
▪
Pass Certification exam: …….. Certification Exam id: ……….. Exam Title: ……… Mark: ………
Fails Certification exam: …….. Certification Exam id: ……….. Exam Title: ……… Mark: ……… Number Of Days to Wait ……

"""
from person import Person
from certificationExam import CertificationExam

class Candidate(Person):
    ##constructor
    __seqCandidate = 1000
    def __init__(self, last_name, first_name, phone, certificationExam, examDate):
        super().__init__(last_name, first_name, phone)
        self.__id = Candidate.__seqCandidate
        Candidate.__seqCandidate += 1
        self._certificationExam = certificationExam
        self._examDate = examDate
        self._examMark = None
        self._grade = None
        self._nbDaysToWait = None

    ## getters and setters

    def getCertificationExam(self):
        return self._certificationExam
    
    def getExamDate(self):
        return self._examDate
    
    def getExamMark(self):
        return self._examMark
    
    def setCertificationExam(self):
        return self._certificationExam
    
    def setExamDate(self):
        return self._examDate
    
    def setExamMark(self, examMark):
        self._examMark = examMark

    ## methods 
    def serviceSuccess(self, grade):
        self._grade = grade

    def serviceFail(self, nod):
        self._nbDaysToWait = nod

    def __str__(self):
        if self._grade != None:
            return f"Pass certification exam: {self.getFirstName()} {self.getLastName()}, Certification Exam Identification: {self._certificationExam.getId()} Exam Title: {self._certificationExam.getTitle()} Mark: {self._examMark}"
        else:
            self.serviceFail(self._certificationExam.getDaysWait())
            return f"Fails certification exam: {self.getFirstName()} {self.getLastName()}, Certification Exam Identification: {self._certificationExam.getId()} Exam Title: {self._certificationExam.getTitle()} Mark: {self._examMark} Number Of Days to Wait {self._nbDaysToWait}" 