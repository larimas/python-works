"""

student: larissa
question 5:
5. Create the class DoCertificationExam with the following characterises:
• Attributes:
▪ candidate type Candidate
▪ Two objects from CertificationExam class {1z0-151: Java and 1z0-147: Python)
• Constructor:
▪ Create a constructor and call the method validateCertification.
• Methods:
▪ The class provides access methods to all attributes
▪ getGrade takes examMark
▪ getMark takes examId and Candidate Last name. the method reads from
a text file named marks.txt and retrieve the exam mark from file from the last name and exam ID.
▪validateCertification takes no argument and check whether if the mark ispassed, then check the grade according to the mark and then set it as theparameter of serviceSuccess. If not passed, set the number days forwaiting for serviceFaillure.
▪The class overrides the method toString() to return the following output :
(examMark >=95) → A+
(examMark >=90 && examMark<95) → A
(examMark >=85 && examMark<=90) → B+
(examMark >=80 && examMark<=85) → B
(examMark >=75 && examMark<=80) → C+
(examMark >=70 && examMark<=75) → C
(examMark >=65 && examMark<=70) → D+
(examMark >=60 && examMark<=65) → D
(examMark <60) → E

"""
from certificationExam import CertificationExam
from candidate import Candidate

class DoCertificationExam:

    def __init__(self, candidate):
        self._candidate = candidate
        self._Java = CertificationExam("1z0-151","Java", 60, 30)
        self._Python = CertificationExam("1z0-147","Python", 70, 20)
        self._validateCertification()
    ## get and setters
    def getCandidate(self):
        return self._candidate
    
    def getJava(self):
        return self._Java
    
    def getPython(self):
        return self._Python
    
    def setCandidate(self, candidate):
        self._candidate = candidate
    
    ## read text file
    
    def readFile():
        fd = open("Mark.txt", "r")
        candidates = fd.readlines()
        candidateMark = ()
        for candidate in candidates:
            candidate = candidate.strip()
            candidate.split(",")
            if len(candidate)==3:
                examId = candidate[0]
                lastName = candidate[1]
                mark = candidate[2]
                candidateMark[examId, lastName] = int(mark)
        fd.close()
        return candidateMark


    def getMark(self, examId, lastName):
        candidateMarks = self.readFile()
        return candidateMarks.get((examId, lastName), -1)
    
    def getGrade(self, examMark):
        if examMark >= 95:
            return "A+"
        elif examMark >= 90:
            return "A"
        elif examMark >= 85:
            return "B+"
        elif examMark >= 80:
            return "B"
        elif examMark >= 75:
            return "C+"
        elif examMark >= 70:
            return "C"
        elif examMark >= 65:
            return "D+"
        elif examMark >= 60:
            return "D"
        else:
            return "E"

    def validateCertification(self):
        javaMark = self.getMark(self._Java.getId(), self._candidate.getLastName())
        
        if javaMark >= self._Java.getSuccessMark():
            examGrade = self.getGrade(javaMark)
            self._candidate.serviceSuccess(examGrade)
        else:
            self.candidate.serviceFail(self._Java.getDaysWait())
    
        pythonMark = self.getMark(self._Python.getId(), self._candidate.getLastName())
        
        if pythonMark >= self._Python.getSuccessMark():
            examGrade = self.getGrade(pythonMark)
            self._candidate.serviceSuccess(examGrade)
        else:
            Candidate.serviceFail(self._Python.getDaysWait())

## return method

    def __str__(self):

        return f"{self._candidate}"