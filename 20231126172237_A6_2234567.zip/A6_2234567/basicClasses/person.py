"""

student: larissa
question 1-2:
1.Create a project with a basic package called basicClasses contains the Person,Candidate, DoCertificationExam, CertificationExam.
2.Create the class Person with the following characterises:
•Attributes:
▪Last Name
▪First Name
▪Phone type
•Constructor:
▪Create a parameterized constructor.
•Methods:
▪The class provides access methods to all attributes and modifies theattributes phone, last name and first name
▪The class overrides the method toString() to return the following output :
First Name: …….. Last Name : ……….. Phone : ………

"""

class Person:

    ## constructors

    def __init__(self, last_name, first_name, phone_type):
        self._last_name = last_name
        self._first_name = first_name
        self._phone_type = phone_type

    ## getters and setters

    def getLastName(self):
        return self._last_name
    
    def getFirstName(self):
        return self._first_name
    
    def getPhoneType(self):
        return self._phone_type

    def setLastName(self, lastName):
        self._last_name = lastName

    def setFirstName(self, firstName):
        self._first_name = firstName

    def setPhoneType(self, phoneType):
        self._phone_type = phoneType
    
    ## toString method/return
    def __str__(self):
        return f"First name: {self._first_name}, Last name: {self._last_name}, Telephone: {self._phone_type}"