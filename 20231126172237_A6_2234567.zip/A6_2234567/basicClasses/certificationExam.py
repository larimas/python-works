"""

student: larissa
question 3:
3.Create the class CertificationExam with the following characterises:
•Attributes:
▪id
▪title
▪successMark
▪number of days wait.
•Constructor:
▪Create a parameterized constructor.
•Methods:
▪The class provides access methods to all attributes and modifies theattributes number of days wait, successMark
▪The class overrides the method toString() to return the following output :
ID: …….. Title: ……….. Success Mark: ……… Number of Days to Wait: ………

"""
class CertificationExam:
    __seq = 100
    ## constructors
    def __init__(self, id, title, success_mark, days_wait):
        self._id = id
        self._title = title
        self._success_mark = success_mark
        self._days_wait = days_wait

    ## getters and setters
    def getId(self):
        return self._id
    
    def getTitle(self):
        return self._title
    
    def getSuccessMark(self):
        return self._success_mark
    
    def getDaysWait(self):
        return self._days_wait

    def setTitle(self, title):
        self._title = title

    def setDaysWait(self, daysWait):
        self._days_wait = daysWait

    def setSuccessMark(self, successMark):
        self._success_mark = successMark
    
    ## toString method/return
    def __str__(self):
        return f"ID: {self._id}, title: {self._title}, cuccess mark: {self._success_mark} and nº of waiting days: {self._days_wait}"