"""
student: larissa
the main file
"""
from certificationExam import CertificationExam
from person import Person
from candidate import Candidate
from doCertificationExam import DoCertificationExam

if __name__ == '__main__':

    certification1 = CertificationExam("1z0-151","Java", 60, 30)
    print(certification1)
    p1 = Person("London", "John", "111111111")
    print(p1)
    candidate1 = Candidate("London", "John", "111111111", certification1, "2021-01-02")

    certification2 = CertificationExam("1z0-147","Python", 70, 20)
    print(certification2)
    p2 = Person("Smith", "Jane", "222222222")
    print(p2)
    candidate2 = Candidate("Smith", "Jane", "222222222", certification1, "2021-01-01")

    p3 = Person("Jordan", "Michael", "333333333")
    print(p3)
    candidate3 = Candidate("Jordan", "Michael", "333333333", certification2, "2021-01-02")

    print(candidate1)
    print(candidate2)
    print(candidate3)

    candidate1.setExamMark(60)