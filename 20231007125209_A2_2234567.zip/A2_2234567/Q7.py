"""
student: larissa
question 7: Write a Python program to construct the following pattern, using a nested for loop.
* 
**
***
****
*****
****
***
**
*
"""
star=5;
for i in range(star):
    for j in range(i):
        print ('*', end = " ")
    print()

for i in range(star,0,-1):
    for j in range(i):
        print('*', end = " ")
    print()