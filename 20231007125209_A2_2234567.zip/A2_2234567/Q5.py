"""
student: larissa
question 5: Given an input list removes the element at index 4 and add it to the 2nd position and also, at the end of the list
List = [54, 44, 27, 79, 91, 41]
"""
given_list = [54, 44, 27, 79, 91, 41] 

print("Original list ", given_list)
element = given_list.pop(4)
print("List after removing at index 4 ", given_list)

given_list.insert(2, element)
print("List after adding at index 2 ", given_list)

given_list.append(element)
print("List after adding at last ", given_list)

