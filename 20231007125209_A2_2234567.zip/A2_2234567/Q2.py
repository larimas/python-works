"""
student: larissa
question 2: Given an input string Count all lower case, upper case, digits, and special symbols
"""

string = input("Enter a string: ")

lower_char = 0; upper_char = 0; number_char = 0; special_char = 0

for char in string:
    if char.islower():
        lower_char += 1
    elif char.isupper():
        upper_char += 1
    elif char.isdigit():
        number_char += 1
    else:
        special_char +=1 
print('\nUpper case characters: ',upper_char)
print('Lower case characters: ',lower_char)
print('Number characters: ',number_char)
print('Special case characters: ',special_char)