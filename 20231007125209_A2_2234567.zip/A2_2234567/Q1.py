"""
student: larissa
question 1 - arrange String characters such that lowercase letters should come first
Given input String of combination of the lower and upper case arrange characters in such a way that all lowercase letters should come first.
Example:
Input: "PyNaTive" Output: " aeivyNPT "
"""

str1 = "PyNaTive"

lowercase_chars = ""
uppercase_chars = ""
for char in sorted(str1):
  if char.islower():
    lowercase_chars += char
  else:
    uppercase_chars += char
output_str = lowercase_chars + uppercase_chars
print(output_str)