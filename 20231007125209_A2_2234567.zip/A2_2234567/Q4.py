"""
student: larissa
question 4: Given a two list. Create a third list by picking an odd-index element from the first list and even index elements from second.
listOne = [3, 6, 9, 12, 15, 18, 21]
listTwo = [4, 8, 12, 16, 20, 24, 28]
"""
list1 = [3, 6, 9, 12, 15, 18, 21]
list2 = [4, 8, 12, 16, 20, 24, 28]
result = list()

odd_numbers = list1[1::2]
print("Element at odd-index positions :")
print(odd_numbers)

even_numbers = list2[0::2]
print("Element at even-index positions :")
print(even_numbers)

print("Third list with all : ")
result.extend(odd_numbers)
result.extend(even_numbers)
print(result)
