"""
student: larissa
question 6: Write a Python program to reverse a given string
Example:
Input: "python"
Output: "nohtyp"
"""
str = str(input("Enter a string : "))
print(str[::-1])