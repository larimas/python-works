"""
student: larissa
question 8: Write a Python program to display astrological sign for given date of birth. Expected Output:
Input birthbirthday: 15
Input month of birth (e.g. march, july etc): may Your Astrological sign is : Taurus
"""
birthday = int(input("Input birthday number: "))
month = input("Input month of birth (e.g. march, july etc): ")
if month == 'december':
	astro_sign = 'Sagittarius' if (birthday < 22) else 'capricorn'
elif month == 'january':
	astro_sign = 'Capricorn' if (birthday < 20) else 'aquarius'
elif month == 'february':
	astro_sign = 'Aquarius' if (birthday < 19) else 'pisces'
elif month == 'march':
	astro_sign = 'Pisces' if (birthday < 21) else 'aries'
elif month == 'april':
	astro_sign = 'Aries' if (birthday < 20) else 'taurus'
elif month == 'may':
	astro_sign = 'Taurus' if (birthday < 21) else 'gemini'
elif month == 'june':
	astro_sign = 'Gemini' if (birthday < 21) else 'cancer'
elif month == 'july':
	astro_sign = 'Cancer' if (birthday < 23) else 'leo'
elif month == 'august':
	astro_sign = 'Leo' if (birthday < 23) else 'virgo'
elif month == 'september':
	astro_sign = 'Virgo' if (birthday < 23) else 'libra'
elif month == 'october':
	astro_sign = 'Libra' if (birthday < 23) else 'scorpio'
elif month == 'november':
	astro_sign = 'scorpio' if (birthday < 22) else 'sagittarius'
else:
    astro_sign = False
if astro_sign:
    print("Your Astrological sign is :",astro_sign)
else:
    print("Invalid data, please enter correctly.")
