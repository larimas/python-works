"""
student: larissa
question 3: String characters balance Test
We’ll say that a String s1 and s2 is balanced if all the chars in the string1 are there in s2. characters position doesn’t matter.
Example:
s1 = "yn" s2 = "Pynative" Output: s1 and s2 are balanced True
s1 = "ynf" s2 = "Pynative" Output: s1 and s2 are balanced False
"""

def string_balance_test(string1, string2):
    result = True
    for char in string1:
        if char in string2:
            continue
        else:
            result = False
    return result


string1 = "yn"
string2 = "Pynative"
result = string_balance_test(string1, string2)
print("s1 and s2 are balanced:", result)

string1 = "ynf"
string2 = "Pynative"
result = string_balance_test(string1, string2)
print("s1 and s2 are balanced:", result)