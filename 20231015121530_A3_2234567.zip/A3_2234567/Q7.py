"""
student: larissa
question 7 - Remove duplicate from a list and create a tuple and find the minimum and maximum number.
sampleList = [87, 45, 41, 65, 94, 41, 99, 94]
"""
sampleList = [87, 45, 41, 65, 94, 41, 99, 94]
print(sampleList)
sampleList = list(set(sampleList))
tupleList = tuple(sampleList)
print("Tuple list: ", tupleList)

print("Minimum number: ", min(tupleList))
print("Maximum number: ", max(tupleList))