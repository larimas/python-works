"""
student: larissa
question 8: Given an input string, count occurrences of all characters within a string
Example:
Input: "pynativepynvepynative"
Output: {'p': 3, 'y': 3, 'n': 3, 'a': 2, 't': 2, 'i': 2, 'v': 3, 'e': 3}
"""
inputString = "pynativepynvepynative"
print("Original string: ", inputString)
##create a dictionary
dict = {}
##check if the character is in the dict
##if not add 1 and put the char in the dict
for char in inputString:
    if char in dict:
        dict[char] += 1
    else:
        dict[char] = 1

print ("Output: ", dict)