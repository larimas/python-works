"""
student: larissa
question 4 - Given two sets, checks if One Set is Subset or superset of Another Set. 
if the subset is found delete all elements from that set
firstSet = {27, 43, 34}
secondSet = {34, 93, 22, 27, 43, 53, 48}
"""
firstSet = {27, 43, 34}
secondSet = {34, 93, 22, 27, 43, 53, 48}

print("First Set: ", firstSet)
print("Second Set: ", secondSet)

print("First set is subset of 2nd set -", firstSet.issubset(secondSet))
print("Second set is subset of 1st set - ", secondSet.issubset(firstSet))

print("First set is super set of 2nd set - ", firstSet.issuperset(secondSet))
print("Second set is super set of 1st set - ", secondSet.issuperset(firstSet))

if firstSet.issubset(secondSet):
    firstSet.clear()

if secondSet.issubset(firstSet):
    secondSet.clear()

print("First Set ", firstSet)
print("Second Set ", secondSet)