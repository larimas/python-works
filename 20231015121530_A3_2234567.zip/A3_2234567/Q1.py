"""
student: larissa
question 1 - Given a list slice it into three chunks, (the last one could be equal with others) 
and then display in normal order and reverse order.
"""
l = [1, 2, 3, 4, 5, 6, 7, 8, 9]  
   
# How many numbers each chunk should have  
n = 3
print(l) 
# normal order
chunk = [l[i:i + n] for i in range(0, len(l), n)]  
print(chunk) 
# in reverse
for l in chunk:
    chunk.reverse()
print(chunk)