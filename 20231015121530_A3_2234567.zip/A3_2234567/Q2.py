"""
student: larissa
question 2 - Given a list from a to e, iterate through the list, and count the occurrence of each element
and create a dictionary to show the count of each element.
sampleList = ['a', 'c', 'b', 'd', 'd', 'a', 'e', 'a', 'e']
Expected Outcome: dict = {'a': 3, 'c': 1, 'b': 1, 'd': 2, 'e': 2}
"""
listElements = ['a', 'c', 'b', 'd', 'd', 'a', 'e', 'a', 'e']
print(listElements)
dict = {}

for char in listElements:
    if char in dict:
        dict[char] += 1
    else:
        dict[char] = 1
print (dict)