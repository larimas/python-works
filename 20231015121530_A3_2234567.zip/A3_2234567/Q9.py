"""
student: larissa
question 9: Given a list iterate it and count the occurrence of each element 
and create a dictionary to show the count of each element.
For example: list = [10, 20, 30, 10, 20, 40, 50]
Expected Outcome: dict = {10: 2, 20: 2, 30: 1, 40: 1, 50: 1}
"""
list = [10, 20, 30, 10, 20, 40, 50]
print("Original list: ", list)
##create a dictionary
dict = {}
##check if the character is in the dict
##if not add 1 and put the char in the dict
for value in list:
    if value in dict:
        dict[value] += 1
    else:
        dict[value] = 1

print ("Expected Outcome: ", dict)