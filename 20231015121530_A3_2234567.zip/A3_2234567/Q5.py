"""
student: larissa
question 5: Iterate a given list and check if a given element already exists in a dictionary as a key’s value,
display the output as a set and if not delete it from the set
rollNumber = [47, 64, 69, 37, 76, 83, 95, 97]
sampleDict ={'Jhon':47, 'Emma':69, 'Kelly':76, 'Jason':97}
"""
rollNumber = [47, 64, 69, 37, 76, 83, 95, 97]
sampleDict = {'Jhon': 47, 'Emma': 69, 'Kelly': 76, 'Jason': 97}

output = set()

for i in rollNumber:
    if i in sampleDict.values():
        output.add(i)

print(f"Output: {output}")