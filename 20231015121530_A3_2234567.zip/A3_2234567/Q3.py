"""
student: larissa
question 3 - Given a two list of equal size create a set such that it shows the element from both lists in the pair.
"""
firstList = [1, 3, 6, 9, 12]
print("First List ", firstList)

secondList = [2, 4, 6, 8, 10]
print("Second List ", secondList)

pairs = set(zip(firstList, secondList))
print(pairs)